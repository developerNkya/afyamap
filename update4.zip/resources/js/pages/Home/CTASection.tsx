import React from 'react';
import { motion } from 'framer-motion';
import { Rocket, MessageCircle, CheckCircle2 } from 'lucide-react';
import { router } from '@inertiajs/react';

export const CTASection = () => {
  return (
    <section className="py-16 sm:py-20 bg-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <h2 className="text-2xl sm:text-3xl font-bold text-afya-text mb-3 sm:mb-4">
            Are you a Facility Administrator?
          </h2>
          <p className="text-base sm:text-lg text-gray-600 mb-6 sm:mb-8 px-4">
            Keep your facility's information up to date, display your latest
            SafeCare level, and respond to patient reviews.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-3 sm:gap-4 px-4">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => router.get('/admin/login')}
              className="bg-afya-deep text-white px-6 sm:px-8 py-2.5 sm:py-3 rounded-xl font-bold hover:bg-opacity-90 transition-colors flex items-center gap-2 justify-center text-sm sm:text-base"
            >
              <Rocket size={16} />
              Admin Login
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => router.get('/contact')}
              className="bg-white text-afya-deep border-2 border-afya-deep px-6 sm:px-8 py-2.5 sm:py-3 rounded-xl font-bold hover:bg-afya-light transition-colors flex items-center gap-2 justify-center text-sm sm:text-base"
            >
              <MessageCircle size={16} />
              Contact Support
            </motion.button>
          </div>
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="text-xs sm:text-sm text-gray-500 mt-6 flex items-center justify-center gap-1"
          >
            <CheckCircle2 className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-afya-deep" />
            Free listing for verified facilities
          </motion.p>
        </motion.div>
      </div>
    </section>
  );
};